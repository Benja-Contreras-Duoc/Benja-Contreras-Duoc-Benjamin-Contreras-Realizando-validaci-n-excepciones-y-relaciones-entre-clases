package model;

// Clase base. Todas las personas de la agencia tienen estos datos.
public class Persona {

    private String nombre;
    private String rut;
    private String telefono;
    private Direccion direccion; // composicion: Persona "tiene una" Direccion

    public Persona(String nombre, String rut, String telefono, Direccion direccion) {
        this.nombre = nombre;
        this.rut = rut;
        this.telefono = telefono;
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre
                + "\nRUT: " + rut
                + "\nTelefono: " + telefono
                + "\nDireccion: " + direccion;
    }
}

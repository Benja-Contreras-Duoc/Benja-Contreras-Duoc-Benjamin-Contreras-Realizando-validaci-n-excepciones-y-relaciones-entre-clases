package model;

// Cliente tambien hereda de Persona. Agrega el tour que contrato.
public class Cliente extends Persona {

    private String tourContratado;

    public Cliente(String nombre, String rut, String telefono, Direccion direccion,
                   String tourContratado) {
        super(nombre, rut, telefono, direccion);
        this.tourContratado = tourContratado;
    }

    public String getTourContratado() {
        return tourContratado;
    }

    public void setTourContratado(String tourContratado) {
        this.tourContratado = tourContratado;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nTour contratado: " + tourContratado;
    }
}

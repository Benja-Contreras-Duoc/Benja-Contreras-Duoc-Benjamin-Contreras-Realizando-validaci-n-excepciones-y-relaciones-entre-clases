package model;

// Empleado hereda de Persona (extends), o sea, es una Persona
// pero con datos extra: cargo y sueldo.
public class Empleado extends Persona {

    private String cargo;
    private int sueldo;

    public Empleado(String nombre, String rut, String telefono, Direccion direccion,
                    String cargo, int sueldo) {
        super(nombre, rut, telefono, direccion); // llama al constructor de Persona
        this.cargo = cargo;
        this.sueldo = sueldo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nCargo: " + cargo
                + "\nSueldo: $" + sueldo;
    }
}

package app;

import model.Cliente;
import model.Direccion;
import model.Empleado;

public class Main {

    public static void main(String[] args) {

        System.out.println("=== Llanquihue Tour ===");
        System.out.println();

        // Objeto 1: un empleado (guia turistico)
        Direccion dir1 = new Direccion("Av. Vicente Perez Rosales", 120, "Llanquihue", "Los Lagos");
        Empleado guia = new Empleado("Camila Soto", "12.345.678-9", "+56 9 1111 2222",
                dir1, "Guia turistica", 650000);

        // Objeto 2: otro empleado (coordinador)
        Direccion dir2 = new Direccion("Calle Ernesto Frei", 45, "Llanquihue", "Los Lagos");
        Empleado coordinador = new Empleado("Pedro Muñoz", "11.222.333-4", "+56 9 3333 4444",
                dir2, "Coordinador de tours", 800000);

        // Objeto 3: un cliente
        Direccion dir3 = new Direccion("Los Aromos", 300, "Santiago", "Metropolitana");
        Cliente cliente = new Cliente("Javiera Rojas", "15.987.654-3", "+56 9 5555 6666",
                dir3, "Paseo lacustre por el Lago Llanquihue");

        System.out.println("--- Empleado 1 ---");
        System.out.println(guia);
        System.out.println();

        System.out.println("--- Empleado 2 ---");
        System.out.println(coordinador);
        System.out.println();

        System.out.println("--- Cliente ---");
        System.out.println(cliente);
    }
}

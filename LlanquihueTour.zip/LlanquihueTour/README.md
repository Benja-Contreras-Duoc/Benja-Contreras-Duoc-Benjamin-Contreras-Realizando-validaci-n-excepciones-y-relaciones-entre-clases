# Llanquihue Tour

## Descripción
Prototipo en Java para la agencia de turismo **Llanquihue Tour** (Región de Los Lagos). Representa a las personas de la empresa (empleados y clientes) usando programación orientada a objetos: encapsulamiento, herencia y composición.

## Estructura del proyecto
```
LlanquihueTour/
└── src/
    ├── model/
    │   ├── Direccion.java   (dirección de una persona)
    │   ├── Persona.java     (clase base, contiene una Direccion)
    │   ├── Empleado.java    (hereda de Persona: cargo y sueldo)
    │   └── Cliente.java     (hereda de Persona: tour contratado)
    └── app/
        └── Main.java        (crea los objetos y los muestra por consola)
```

## Relaciones entre clases
- **Composición:** `Persona` tiene un atributo `Direccion`.
- **Herencia:** `Empleado` y `Cliente` extienden de `Persona`.

## Cómo compilar y ejecutar
### Con IntelliJ IDEA
1. Abrir la carpeta del proyecto.
2. Abrir `src/app/Main.java`.
3. Presionar el botón verde de *Run*.

### Con la terminal
```
cd LlanquihueTour
javac -d out src/model/*.java src/app/Main.java
java -cp out app.Main
```

## Autor
Nombre del estudiante (completar)
